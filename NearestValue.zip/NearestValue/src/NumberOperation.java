/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author emins
 */
public abstract class NumberOperation extends Operation {
    protected String getStringValue(){
        return null;
    }
    final double value;
    
    NumberOperation(Number value){
        super(null, null);
        this.value = value.doubleValue();
    }

    NumberOperation(NumberOperation leftChild, NumberOperation rightChild) {
        super(leftChild, rightChild);
        this.value = Double.NaN;
    }


}
