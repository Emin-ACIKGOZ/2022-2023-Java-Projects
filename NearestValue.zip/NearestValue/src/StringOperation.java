/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author emins
 */
public abstract class StringOperation extends Operation {
    final String value;
    public StringOperation(String value) {
        super(null,null);
        this.value = value;
    }
    public StringOperation(StringOperation leftChild, StringOperation rightChild) {
        super(leftChild, rightChild);
        this.value = null;
    }
    
}
