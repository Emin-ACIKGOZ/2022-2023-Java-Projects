

/**
 *
 * @author emins
 */
public class NearestValue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NumberNode test1 = new NumberNode(12);
        NumberNode test2 = new NumberNode(5);
        NumberAddition test3 = new NumberAddition(test1,test2);
        NumberAddition test4 = new NumberAddition(test3 , test3);
        
        System.out.println(test4 + " = " + test4.getNumberValue());
    }
    
}
