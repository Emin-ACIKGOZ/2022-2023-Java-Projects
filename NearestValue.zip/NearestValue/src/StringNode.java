/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author emins
 */
public class StringNode extends StringOperation {
        StringNode(String value){
        super(value);
    }


    @Override
    public String toString() {
        return this.value;
    }

    @Override
    protected double getNumberValue() {
        return this.value.hashCode();
    }

    @Override
    protected String getStringValue() {
        return this.value;
    }
}
