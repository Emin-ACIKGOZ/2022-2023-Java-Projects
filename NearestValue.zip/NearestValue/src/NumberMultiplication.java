/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author emins
 */
public class NumberMultiplication extends NumberOperation {

    NumberMultiplication(NumberOperation leftChild, NumberOperation rightChild) {
        super(leftChild, rightChild);
    }
        @Override
    protected double getNumberValue() {
        if (this.isLeaf()) {
            return this.value;
        } else {
            return leftChild.getNumberValue() * rightChild.getNumberValue();
        }
    }

    @Override
    public String toString() {
        if (this.isLeaf()) {
            return this.value + "";
        }else{
            return "(" + leftChild.toString() + " * " + rightChild.toString() + ")";
        }
        
    }
}
