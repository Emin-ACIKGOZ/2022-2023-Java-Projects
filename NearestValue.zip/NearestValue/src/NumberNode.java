/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emins
 */
public class NumberNode extends NumberOperation {
    NumberNode(Number value){
        super(value);
    }

    @Override
    protected double getNumberValue() {
        return this.value;
    }

    @Override
    public String toString() {
        return this.value + "";
    }
    
}
