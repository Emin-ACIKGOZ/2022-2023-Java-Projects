package Solution;


public class IntOperator extends Operator{
	
	public final int value;
	
	IntOperator(int value){
		this.value = value;
	}
	
	
	
	@Override
	Operator add(Operator op) {
		
		IntOperator intOp = (IntOperator) op;
		
		int intVal = intOp.value;
		
		
		return new IntOperator(this.value + intVal);
	}

	@Override
	Operator multiply(Operator op) {
		IntOperator intOp = (IntOperator) op;
		
		int intVal = intOp.value;
		
		return new IntOperator(this.value * intVal);
		
	}

	@Override
	Operator subtract(Operator op) {
		IntOperator intOp = (IntOperator) op;
		int intVal = intOp.value;
		
		return new IntOperator(this.value - intVal);
	}


	@Override
	public String toString() {
		return ""+ this.value;
	}
	
	

	
}
