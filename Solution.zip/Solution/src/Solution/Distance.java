package Solution;

public class Distance {

    public static int findDistance(Operator op, Operator target) {

        if (op.getClass().getName() == IntOperator.class.getName() && op.getClass().getName() == target.getClass().getName()) {

            IntOperator intOp = (IntOperator) op;
            IntOperator intTarget = (IntOperator) target;

            return Math.abs(intOp.value - intTarget.value);

        } else if (op.getClass().getName() == StrOperator.class.getName() && op.getClass().getName() == target.getClass().getName()) {
            StrOperator strOp = (StrOperator) op;
            StrOperator targetOp = (StrOperator) target;
            String opValue = strOp.value;
            
            System.out.println(getDistance("KILIT", "LITIK"));
            System.out.println(getDistance("KILIT", "KILITI"));
            return getDistance(opValue, targetOp.value);
            
            
        }

        return Integer.MAX_VALUE;
    }

    public static int getDistance(String str1, String str2) {
        int n1 = str1.length();
        int n2 = str2.length();
        int n = Math.max(n1, n2);

        int distance = 0;
        for (int i = 0; i < n; i++) {
            char ch1 = (i < n1 ? str1.charAt(i) : ' ');
            char ch2 = (i < n2 ? str2.charAt(i) : ' ');

            distance += Math.abs(ch1 - ch2);
        }

        return distance;
    }

}
