package Solution;

import static Solution.Distance.findDistance;
import java.util.ArrayList;
import java.util.List;

public class OpSolver {

    static int smallestDistance = Integer.MAX_VALUE;
    static Operator closestOp = null;
    static String solution = "";
    static String opString = "";

    public static void main(String[] args) {
        Operator[] input = {
            new StrOperator("K"),
            new StrOperator("LT"),
            new StrOperator("I"),
        };
        
        Operator target = new StrOperator("KILIT");
        
        long start = System.nanoTime();
        findClosestCombination(input, target);
        long finish = System.nanoTime();
        
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");
        System.out.println(opString);
        System.out.println("Solution: " + solution + " = " + closestOp);
        System.out.println("Target: " + target);

    }

    private static void findClosestCombination(Operator[] set, Operator target) {
        OpSolver.combinationCreator(set, new ArrayList<>(), target);
    }

    private static void combinationCreator(Operator[] set, List<Operator> combination, Operator target) {
        if (smallestDistance == 0) {
            return;
        }

        if (!combination.isEmpty()) {
            operationCombination(combination, target, combination.get(0), 1, "");
        }
        //System.out.println(combination);

        for (int i = 0; i < set.length; i++) {
            List<Operator> tempSet = new ArrayList<>();

            combination.add(set[i]);
            for (int j = 0; j < set.length; j++) {
                if (j != i) {
                    tempSet.add(set[j]);
                }
            }

            OpSolver.combinationCreator(tempSet.toArray(Operator[]::new), combination, target);
            combination.remove(combination.size() - 1);
        }
    }

    private static void operationCombination(List<Operator> values, Operator target, Operator current, int index, String Ops) {
        int distance = findDistance(current, target);
        if (closestOp == null || distance < smallestDistance) {
            closestOp = current;
            smallestDistance = distance;
            opString = Ops;
            generateSolution(values, Ops);
        }
        if (values.isEmpty() || index >= values.size() || smallestDistance == 0) {
            return;
        }
        //StringBuilder Op = "(" + current + ""
        operationCombination(values, target, current.multiply(values.get(index)), index + 1, Ops + "*");
        operationCombination(values, target, current.add(values.get(index)), index + 1, Ops + "+");
        operationCombination(values, target, current.subtract(values.get(index)), index + 1, Ops + "-");

    }

    private static void generateSolution(List<Operator> values, String Ops) {
        if (values.size() == 1) {
            solution = values.get(0).toString();
        } else {
            StringBuilder sb = new StringBuilder();
            int size = Ops.length();
            sb.append("(").append(values.get(0)).append(Ops.charAt(0)).append(values.get(1)).append(")");
            for (int i = 1; i < size; i++) {
                sb.insert(0, "(");
                sb.append(Ops.charAt(i)).append(values.get(i + 1).toString()).append(")");
            }
            solution = sb.toString();
        }

    }
}


