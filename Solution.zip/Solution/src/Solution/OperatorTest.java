package Solution;


public class OperatorTest {

	
	
	public static void main(String[]args) {
		
		//Int Operator Test 
		System.out.println("Integer Operator Test");
		System.out.println();
		
		Operator op1 = new IntOperator(12);
		Operator op2 = new IntOperator(5);
		System.out.println(op1.add(op2));
		System.out.println(op1.multiply(op2));
		System.out.println(op1.subtract(op2));
		
		System.out.println("----------");
		System.out.println();
		
		
		
		
		
		// Str Operator Test
		System.out.println("String Operator Test");
		Operator op3 = new StrOperator("ABCD");
		Operator op4 = new StrOperator("EFGH");
		//ABCDEFGH
		System.out.println(op3.add(op4));
		Operator op5 = op3.add(op4);
		System.out.println(op5.subtract(op3));
		
		Operator N = new StrOperator("N");
		Operator A = new StrOperator("A");
		Operator R = new StrOperator("R");
		
		Operator NARA = new StrOperator((N.add(R).multiply(A)).toString());
		//NARA
		System.out.println(NARA);
		
		Operator B = new StrOperator("B");
		//NARA
		System.out.println(NARA.subtract(B));
		//NAR
		System.out.println(NARA.subtract(A));
		
		
		System.out.println("----------");
		System.out.println();
		
		
		
		
		
		
		//Distance Test
		
		//7
		int i = Distance.findDistance(op1,new IntOperator(5));
		System.out.println(i);
		
		//55
		int j = Distance.findDistance(op1.multiply(op2),new IntOperator(5));
		System.out.println(j);
		
		//36
		Operator ABC = new StrOperator("ABC");
		int k = Distance.findDistance(ABC, new StrOperator(op3.toString()));
		System.out.println(k);
		
		// op1 = IntOperator(12)
		//Integer.MAXVALUE
		int l = Distance.findDistance(op1, new StrOperator("ABC"));
		System.out.println(l);
		
		//128
		int m = Distance.findDistance(NARA, new StrOperator("B"));
		System.out.println(m);
		
		//0 
		int n = Distance.findDistance(NARA, new StrOperator("NARA"));
		System.out.println(n);
		//0
		Operator op6 = new StrOperator("");
		System.out.println(Distance.findDistance(op6, new StrOperator("")));
		
		
		System.out.println("----------");
		System.out.println();
		
		
		
		// Solver Test
		
		Operator[] testArr1 = {
		new IntOperator(2),
		new IntOperator(1),
		new IntOperator(3)
		};
		
		Operator testTarget1 = new IntOperator(8);
		//41
		System.out.println(7);
	}
	
}
