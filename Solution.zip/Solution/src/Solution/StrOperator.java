package Solution;


public class StrOperator extends Operator{

	public final String value;
	
	StrOperator(String value){
		this.value = value;
	}
	
	
	
	@Override
	Operator add(Operator op) {
		StrOperator strOp = (StrOperator) op;

		StringBuilder sb = new StringBuilder(this.value);		
		sb.append(strOp.value);

		
		return new StrOperator(sb.toString());
	}

	@Override
	Operator multiply(Operator op) {
		
		StrOperator strOp = (StrOperator) op;
		
		StringBuilder sb = new StringBuilder();
		
		for(int i = 0;i < this.value.length(); i++) {
			sb.append(this.value.charAt(i));
			sb.append(strOp.value);
		}
		
		return new StrOperator(sb.toString());
	}

	@Override
	Operator subtract(Operator op) {
		StrOperator strOp = (StrOperator) op;
		
		StringBuilder sb = new StringBuilder();
		
		int lastOccurence = this.value.lastIndexOf(strOp.value);
        if(lastOccurence >= 0){
        	sb.append(this.value.substring(0, lastOccurence));
        	sb.append(this.value.substring(lastOccurence+strOp.value.length(),this.value.length()));
        	return new StrOperator(sb.toString());
        }
        else {
        	return new StrOperator(this.value);
        }
	}



	@Override
	public String toString() {
		return this.value;
	}

}
