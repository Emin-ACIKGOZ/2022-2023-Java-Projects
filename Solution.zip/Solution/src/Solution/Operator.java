package Solution;

public abstract class Operator {
	
	
	abstract Operator add(Operator op);
	abstract Operator multiply(Operator op);
	abstract Operator subtract(Operator op);
	
	public abstract String toString();
}
