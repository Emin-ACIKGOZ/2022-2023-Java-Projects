/*
 * 
 * 
 */
package homework.pkg3;

import java.util.Scanner;

/**
 *
 * @author eminsalihacikgoz
 */
public class Emin_Salih_Acikgoz_22050111032_Homework_3 {

    public static int puddle(int[] stoneHeight) {
        int lavaCount = 0;
        int tallest_index_R = 0, tallest_index_L = stoneHeight.length - 1;
        int tallestStone = stoneHeight[0];

        for (int i = 0; i < stoneHeight.length; i++) {
            if (stoneHeight[i] > tallestStone) {
                tallestStone = stoneHeight[i];
                tallest_index_R = i;
            }
        }
        tallestStone = stoneHeight[stoneHeight.length - 1];
        for (int i = stoneHeight.length - 1; i >= 0; i--) {
            if (stoneHeight[i] > tallestStone) {
                tallestStone = stoneHeight[i];
                tallest_index_L = i;
            }
        }

        int localMax = stoneHeight[0];
        for (int i = 0; i < tallest_index_L; i++) {
            if (localMax < stoneHeight[i]) {
                localMax = stoneHeight[i];
            } else if (localMax > stoneHeight[i]) {
                lavaCount += localMax - stoneHeight[i];
            }
        }

        localMax = stoneHeight[stoneHeight.length - 1];
        for (int j = stoneHeight.length - 1; j > tallest_index_R; j--) {
            if (localMax < stoneHeight[j]) {
                localMax = stoneHeight[j];
            } else if (localMax > stoneHeight[j]) {
                lavaCount += localMax - stoneHeight[j];
            }
        }

        if (stoneHeight[tallest_index_L] == stoneHeight[tallest_index_R]) {
            for (int i = tallest_index_R + 1; i < tallest_index_L; i++) {
                lavaCount -= stoneHeight[tallest_index_L] - stoneHeight[i];
            }
        }
        return lavaCount;
        // On lines 20-25 we find the index of the tallest stone from the right side of out grid using a for loop to check each value.
        //The conditional checks if the next stone is taller than the currently tracked tallest stone  

        // On lines 26-32 we find the index of the tallest stone from the left side of out grid using a for loop to check each value.
        // The conditional checks if the next stone is taller than the currently tracked tallest stone         
        /**
         * On lines 34-40 We use the absolute tallest (left) column to check if
         * we can add a lava tile The process works by starting our iteration
         * from the leftmost part of our grid and setting the local maximum of
         * the left side of the absolute tallest column to the leftmost value on
         * the grid. We then check if it is taller than the next column.
         *
         * If it is taller, the amount of addable lava in this column is the
         * local maximum minus the height of the shorter stone. This value is
         * added and the loop continues until the reaches the absolute tallest
         * (left) column.
         *
         * If our local maximum is shorter than the currently compared column,
         * the current column will be set to be the new local maximum.
         *
         * On lines 42-48 our local maximum is now initially set to the
         * rightmost column on our grid, a similar process to the one on lines
         * 37-44 occurs where the process happens from the right towards the
         * left until it reaches the absolute tallest (right) column.
         *
         * On lines 50-54 the for loop only executes when there are two
         * different absolute maximum values that have the same height (for
         * example: 1 2 3 4 0 0 4 3 2 1) in order to not count the lava tiles
         * in-between these two maximums twice.
         *
         *
         */
    }

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int[] stoneHeight = new int[10];
        int height, puddle;
        System.out.println("[!] The Volcano Corollary [!]");
        System.out.println("Please enter 10 different values for the height of each rock formation:");
        for (int i = 0; i < stoneHeight.length; i++) {
            do {
                height = input.nextInt();
                if (height < 0) {
                    System.out.println("Invalid statement entered! Please continue entering from the " + (i + 1) + ". value.");
                    input.nextLine();
                }
            } while (height < 0);
            stoneHeight[i] = height;
            height = -1;
        }

        puddle = puddle(stoneHeight);
        System.out.println("The maximum number of lava tile(s) that can be generated is " + puddle);
    }
}
