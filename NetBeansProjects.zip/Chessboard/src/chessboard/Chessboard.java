package chessboard;

import java.util.Scanner;

// @author eminsalihacikgoz
public class Chessboard {

    static void allWhite(StringBuffer R1, StringBuffer R2, StringBuffer R3, StringBuffer R4, StringBuffer R5, StringBuffer R6, StringBuffer R7, StringBuffer R8){
        R1.replace(0, 8,"00000000");
        R2.replace(0, 8,"00000000");
        R3.replace(0, 8,"00000000");
        R4.replace(0, 8,"00000000");
        R5.replace(0, 8,"00000000");
        R6.replace(0, 8,"00000000");
        R7.replace(0, 8,"00000000");
        R8.replace(0, 8,"00000000");
         //Method turns each string into only 0s. Uses the fact that the identifer is an adress.
    }    
    static void allBlack(StringBuffer R1, StringBuffer R2, StringBuffer R3, StringBuffer R4, StringBuffer R5, StringBuffer R6, StringBuffer R7, StringBuffer R8){
        R1.replace(0, 8,"11111111");
        R2.replace(0, 8,"11111111");
        R3.replace(0, 8,"11111111");
        R4.replace(0, 8,"11111111");
        R5.replace(0, 8,"11111111");
        R6.replace(0, 8,"11111111");
        R7.replace(0, 8,"11111111");
        R8.replace(0, 8,"11111111");
        //Method turns each string into only 1s. Uses the fact that the identifer is an adress.
        
    }    
    static void drawVirtualCB(StringBuffer r1,StringBuffer r2,StringBuffer r3,StringBuffer r4,StringBuffer r5,StringBuffer r6,StringBuffer r7,StringBuffer r8){
        StringBuffer R1 = new StringBuffer (r1);
        StringBuffer R2 = new StringBuffer (r2);
        StringBuffer R3 = new StringBuffer (r3);
        StringBuffer R4 = new StringBuffer (r4);
        StringBuffer R5 = new StringBuffer (r5);
        StringBuffer R6 = new StringBuffer (r6);
        StringBuffer R7 = new StringBuffer (r7);
        StringBuffer R8 = new StringBuffer (r8);
        R1.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R2.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R3.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R4.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R5.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R6.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R7.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        R8.insert(1, "  ").insert(4, "  ").insert(7, "  ").insert(10, "  ").insert(13, "  ").insert(16, "  ").insert(19, "  ");
        System.out.println(R8+"\n"+R7+"\n"+R6+"\n"+R5+"\n"+R4+"\n"+R3+"\n"+R2+"\n"+R1+"\n");
        //This method creates new StringBuffers that have the same order as their corresponding ranks. The inserts add spaces between these values.
    }    
    static void printMenu(){
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        System.out.println("MENU:");
        System.out.println("1 -> Initialize the board to white:");
        System.out.println("2 -> Initialize the board to black:");        
        System.out.println("3 -> Change the major and minor diagonal to black or white:");
        System.out.println("4 -> Enter a rank and file together and make that specific square white or black:");
        System.out.println("5 -> Initialize a proper chessboard:");
        System.out.println("6 -> Draw the chessboard on the console:");
        System.out.println("7 -> Exit the program:");
        System.out.println("=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=");
        //Method prints the menu
    }    
    static void buildProperCB(StringBuffer R1, StringBuffer R2, StringBuffer R3, StringBuffer R4, StringBuffer R5, StringBuffer R6, StringBuffer R7, StringBuffer R8){
        R1.replace(0, 8, "10101010");
        R2.replace(0, 8,"01010101");
        R3.replace(0, 8,"10101010");
        R4.replace(0, 8,"01010101");
        R5.replace(0, 8,"10101010");
        R6.replace(0, 8,"01010101");
        R7.replace(0, 8,"10101010");
        R8.replace(0, 8,"01010101");
        //Method overwrites the ranks to make a checkerboard pattern
        
    }
    static StringBuffer changeSquare(StringBuffer RankX, char fileChar, int BW){
        int fileNum = 8;
        switch(fileChar){
            case 'a' -> {fileNum = 0;}
            case 'b' -> {fileNum = 1;}
            case 'c' -> {fileNum = 2;}
            case 'd' -> {fileNum = 3;}
            case 'e' -> {fileNum = 4;}
            case 'f' -> {fileNum = 5;}
            case 'g' -> {fileNum = 6;}
            case 'h' -> {fileNum = 7;}                
        }
        RankX.replace(fileNum, (fileNum+1), "" + BW);
        return RankX;
        //Item converts the file into an index and modifies the value based on if it's black or white.
    }        
    static void paintDiagonals(StringBuffer R1, StringBuffer R2, StringBuffer R3, StringBuffer R4, StringBuffer R5, StringBuffer R6, StringBuffer R7, StringBuffer R8, int BW ){

                R1.replace(0, 1, "" + BW).replace(7, 8, "" + BW);
                R8.replace(0, 1, "" + BW).replace(7, 8, "" + BW);

                R2.replace(1, 2, "" + BW).replace(6, 7, "" + BW);
                R7.replace(1, 2, "" + BW).replace(6, 7, "" + BW);

                R3.replace(2, 3, "" + BW).replace(5, 6, "" + BW);
                R6.replace(2, 3, "" + BW).replace(5, 6, "" + BW);

                R4.replace(3, 4, "" + BW).replace(4, 5, "" + BW);
                R5.replace(3, 4, "" + BW).replace(4, 5, "" + BW);
            //Method replaces specific parts of each rank with BW (Black or White) to make a diagonal pattern.
    }    
 
    static boolean verifyPosition (String pos){
        boolean rank,file;
        if(pos.length()!=2)
            return false;
        else {
            rank = (pos.charAt(0)>='a' && pos.charAt(0)<='h');
            file = (pos.charAt(1)>='1' && pos.charAt(1)<='8');
            return(rank&&file);
        }
        //Method checks if the user's entered position (pos) is valid, if invalid false is returned.
    }
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        StringBuffer Rank1 = new StringBuffer ("00000000");
        StringBuffer Rank2 = new StringBuffer ("00000000");
        StringBuffer Rank3 = new StringBuffer ("00000000");
        StringBuffer Rank4 = new StringBuffer ("00000000");
        StringBuffer Rank5 = new StringBuffer ("00000000");
        StringBuffer Rank6 = new StringBuffer ("00000000");
        StringBuffer Rank7 = new StringBuffer ("00000000");
        StringBuffer Rank8 = new StringBuffer ("00000000");
        String pos;
        int menuInput;
        int blackWhite;
        
        do{
            printMenu();
            
            do{
                 menuInput= input.nextInt();
                if(menuInput < 1 || menuInput > 7)
                    System.out.println("Invalid! Please try again.");
            }while(menuInput < 1 || menuInput > 7);
            input.nextLine(); // I put these outside of loops that use next- inputs to prevent specific bugs from occuring
        
            switch(menuInput){
                case 7 -> System.out.println("Thanks for using my program! Goodbye.");
                
                case 1 -> {allWhite(Rank1, Rank2,Rank3,Rank4,Rank5,Rank6,Rank7,Rank8);}   
                
                case 2 -> {allBlack(Rank1, Rank2,Rank3,Rank4,Rank5,Rank6,Rank7,Rank8);}
                
                case 3 -> {
                    System.out.println("Enter 1 for Black, 0 for White.");
                    do{
                        blackWhite = input.nextInt();
                        if(blackWhite != 1 && blackWhite != 0){
                            System.out.println("Invalid! Please try again.");
                            blackWhite = -1;
                        }
                        }while(blackWhite == -1);
                        input.nextLine();
                    paintDiagonals(Rank1, Rank2,Rank3,Rank4,Rank5,Rank6,Rank7,Rank8, blackWhite);
                }  
                case 4 -> {
                    System.out.println("Enter 1 for Black, 0 for White.");
                    do{
                        blackWhite = input.nextInt();
                        if(blackWhite != 1 && blackWhite != 0){
                            System.out.println("Invalid! Please try again.");
                            blackWhite = -1;
                        }
                        }while(blackWhite == -1);
                        input.nextLine();
                    
                    System.out.println("Enter the File and Rank (i.e. a4, d7):");
                    do{
                        pos = input.nextLine();
                        if(!verifyPosition(pos))
                        System.out.println("Invalid! Please try again.");
                    }while(!verifyPosition(pos));
                    
                    switch(pos.charAt(1)){
                        case '1' -> {changeSquare(Rank1, pos.charAt(0), blackWhite);}
                        case '2' -> {changeSquare(Rank2, pos.charAt(0), blackWhite);}
                        case '3' -> {changeSquare(Rank3, pos.charAt(0), blackWhite);}
                        case '4' -> {changeSquare(Rank4, pos.charAt(0), blackWhite);}
                        case '5' -> {changeSquare(Rank5, pos.charAt(0), blackWhite);}
                        case '6' -> {changeSquare(Rank6, pos.charAt(0), blackWhite);}
                        case '7' -> {changeSquare(Rank7, pos.charAt(0), blackWhite);}
                        case '8' -> {changeSquare(Rank8, pos.charAt(0), blackWhite);} 
                        //This switch statement checks which rank was entered and chooses the appropiate rank to be changed.
                    }
                }
                
                case 5 -> {
                    buildProperCB(Rank1, Rank2,Rank3,Rank4,Rank5,Rank6,Rank7,Rank8);
                }
                
                case 6 -> drawVirtualCB(Rank1, Rank2,Rank3,Rank4,Rank5,Rank6,Rank7,Rank8); 
            }
        }while(menuInput!=7);
        
    }
    
}
