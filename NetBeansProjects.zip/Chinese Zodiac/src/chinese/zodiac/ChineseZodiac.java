/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chinese.zodiac;

import java.util.Scanner;

/**
 *
 * @author emins
 */
public class ChineseZodiac {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner Scan = new Scanner(System.in);
        System.out.println("Enter the year you were born in to find out your Chinese Zodiac.");
        int year = Scan.nextInt();
        if (year < 0){year = -year;}
        int zodiac = year % 12;
        switch(zodiac)
        {
            case 0 -> System.out.println("Your zodiac is Monkey");
            
                case 1 -> System.out.println("Your zodiac is Rooster");
                
                    case 2 -> System.out.println("Your zodiac is Dog");
                    
                        case 3 -> System.out.println("Your zodiac is Pig");
                        
                            case 4 -> System.out.println("Your zodiac is Rat");
                            
                                case 5 -> System.out.println("Your zodiac is Ox");
                                
                            case 6 -> System.out.println("Your zodiac is Tiger");
                            
                        case 7 -> System.out.println("Your zodiac is Rabbit");
                        
                    case 8 -> System.out.println("Your zodiac is Dragon");
                    
                case 9 -> System.out.println("Your zodiac is Snake");
                
            case 10 -> System.out.println("Your zodiac is Horse");
            
        case 11 -> System.out.println("Your zodiac is Sheep");
        
        default -> System.out.println("Error! Invalid year entered.");
        }
        
    }
    
}
