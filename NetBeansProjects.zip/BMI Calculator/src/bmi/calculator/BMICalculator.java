/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bmi.calculator;

import java.util.Scanner;


public class BMICalculator {


    public static void main(String[] args) {
        double BMI = 0, height = 0, weight = 0;
        Scanner getvalues = new Scanner(System.in);
        System.out.println("Please enter your height in meters: ");
        height = getvalues.nextDouble();
        System.out.println("Please enter your weight in kilograms: ");
        weight = getvalues.nextDouble();
        BMI = weight / (height*height);
        
        if (BMI>=30){
            System.out.println("You are obese. Your BMI is " + BMI);
            }
            else if (BMI>=25) {
                System.out.println("You are overweight. Your BMI is " + BMI);
                }
                else if (BMI>=18.5) {
                    System.out.println("You are at a healthy weight. Your BMI is " + BMI);
                    }
                    else if (18.5 > BMI && BMI > 0) {
                        System.out.println("You are underweight. Your BMI is " + BMI);
                        }
                        else {System.out.println("Invalid BMI. Please try again.");}
    
        getvalues.close();
    }
    
}
