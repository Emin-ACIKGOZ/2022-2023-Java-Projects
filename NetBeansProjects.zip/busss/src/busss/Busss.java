package busss;

import java.util.Arrays;

enum Gender {Male,Female;}

class Passenger {
    Gender gender;
    Passenger(Gender gender) {
        this.gender = gender;
    }
}

class Ticket {
    Passenger ticketOwner;
    Ticket(Passenger ticketOwner) {
        this.ticketOwner = ticketOwner;
    }
}

public class Busss {

    public static void main(String[] args) {

    }

}
