/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package pkg6.letter.random.word;

import java.util.Random;

/**
 *
 * @author emins
 */
public class LetterRandomWord {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        String x;
        String result = "";

        for (int i = 0; i < 6; i++) {
            x = "" + (char) (rand.nextInt(26) + 'a');
            result = result + x;
        }
        System.out.println(result);
    }
}
