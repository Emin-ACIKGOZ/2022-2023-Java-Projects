package Calculation;

public class Calculation{


    public static void main(String[] args) {
        double a = 2.5;
        int b = 4, c = 2, d = 15, k = 4, m = 8;
        double result;
        result = (a*b/c+d)/(k*m);
        System.out.printf("Result of calculation is: %f\n", result);
    }
    
}
