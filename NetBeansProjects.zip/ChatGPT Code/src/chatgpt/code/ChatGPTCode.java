/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package chatgpt.code;

/**
 *
 * @author emins
 */
import java.util.ArrayList;
import java.util.List;
import java.util.Random;



public class ChatGPTCode {
        private static final String[] VOWELS = {"a", "e", "i", "o", "u"};
    private static final String[] CONSONANTS = {"b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n", "p", "q", "r", "s", "t", "v", "w", "x", "y", "z"};

    public static String generateRandomWord() {
        Random random = new Random();
        int length = random.nextInt(10) + 1;
        StringBuilder word = new StringBuilder();

        // Alternate between vowels and consonants to create random word
        boolean isVowel = random.nextBoolean();
        for (int i = 0; i < length; i++) {
            if (isVowel) {
                word.append(VOWELS[random.nextInt(VOWELS.length)]);
            } else {
                word.append(CONSONANTS[random.nextInt(CONSONANTS.length)]);
            }
            isVowel = !isVowel;
        }

        return word.toString();
    }

    public static List<String> generatePermutations(String input) {
        List<String> permutations = new ArrayList<>();
        generatePermutations("", input, permutations);
        return permutations;
    }

    private static void generatePermutations(String prefix, String input, List<String> permutations) {
        int n = input.length();
        if (n == 0) {
            permutations.add(prefix);
        } else {
            for (int i = 0; i < n; i++) {
                generatePermutations(prefix + input.charAt(i), input.substring(0, i) + input.substring(i + 1, n), permutations);
            }
        }
    }

    public static void sort(int[] arr) {
        mergeSort(arr, 0, arr.length - 1);
    }

    private static void mergeSort(int[] arr, int start, int end) {
        if (start < end) {
            int mid = (start + end) / 2;
            mergeSort(arr, start, mid);
            mergeSort(arr, mid + 1, end);
            merge(arr, start, mid, end);
        }
    }

    private static void merge(int[] arr, int start, int mid, int end) {
        int[] temp = new int[end - start + 1];

        int i = start;
        int j = mid + 1;
        int k = 0;

        while (i <= mid && j <= end) {
            if (arr[i] <= arr[j]) {
                temp[k++] = arr[i++];
            } else {
                temp[k++] = arr[j++];
            }
        }

        while (i <= mid) {
            temp[k++] = arr[i++];
        }

        while (j <= end) {
            temp[k++] = arr[j++];
        }

        k = 0;
        for (i = start; i <= end; i++) {
            arr[i] = temp[k++];
        }
    }

    public static double calculateDistance(double x1, double y1, double z1, double x2, double y2, double z2) {
        //Calculate distance using distance formula
        return Math.sqrt(Math.pow((x2 - x1), 2) + Math.pow((y2 - y1), 2) + Math.pow((z2 - z1), 2));
    }

    public static void main(String[] args) {
        List<String> permutations = generatePermutations("abc");
        for (String permutation : permutations) {
            System.out.println(permutation);
            int[] arr = {5, 2, 9, 1, 3, 6, 8, 7};
            sort(arr);
            for (int i : arr) {
                System.out.print(i + " ");
                System.out.println(generateRandomWord());
            }
        }
    }
}
