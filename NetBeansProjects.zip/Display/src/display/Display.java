
package display;


public class Display {


    public static void main(String[] args) {
     double coolNumber = 92.715892;
        System.out.printf("%2.3f\n", coolNumber);
        System.out.printf("%8.4f\n", coolNumber);     
        System.out.printf("%2.0f\n", coolNumber);        
        System.out.printf("%10.5f\n", coolNumber);
        System.out.printf("%7.1f\n", coolNumber);
        System.out.printf("%12.8f\n", coolNumber);
        System.out.printf("%6.0f\n", coolNumber);

    }
    
}
