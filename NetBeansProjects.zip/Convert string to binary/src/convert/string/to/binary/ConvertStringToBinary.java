/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package convert.string.to.binary;

import java.util.Scanner;

/**
 *
 * @author emins
 */
public class ConvertStringToBinary {

    
   
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        
        int num;
        num = Math.abs(input.nextInt());
        int originalNum = num;
        int zeroCheck = 0;
        int bitConversionUnit;
        String binaryString = "";
        
        
            while(num/2 != 0){
            bitConversionUnit = num % 2;
            zeroCheck += bitConversionUnit;
            binaryString = bitConversionUnit + binaryString + ""; 
            num /= 2;
            }
        
        if (originalNum != 0 && zeroCheck == 0){binaryString = "1" + binaryString;}
        
        System.out.println(binaryString);
        
        
        
        
    
    
    }
        
        
        
        
        
        
        
    }
    

