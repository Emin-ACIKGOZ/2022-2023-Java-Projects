package chapter13;

public interface Edible {
  /** Describe how to eat */
  public abstract String howToEat();
}
