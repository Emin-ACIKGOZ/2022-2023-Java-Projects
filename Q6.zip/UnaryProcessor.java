
abstract public class UnaryProcessor extends Processor {
	final protected Number[] data; 

	UnaryProcessor(Number[] data) {
		this.data = data;
	}

	@Override
	final Number[] process() {
		int size = data.length;
		
		Number[] results = new Number[size];	
		
		for (int i=0; i<size; i++) {
			results[i] = NumberUtility.toNumber(processData(i));
		}
		
		return results;
	}
	
}
