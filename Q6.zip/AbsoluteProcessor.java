
public class AbsoluteProcessor extends UnaryProcessor {

	AbsoluteProcessor(Number[] data) {
		super(data);
	}

	@Override
	double processData(int index) {
		double value = data[index].doubleValue(); 
		
		return Math.abs(value);
	}

}
