
abstract public class BinaryProcessor extends Processor {
	final protected Number[] data1; 
	final protected Number[] data2; 

	BinaryProcessor(Number[] data1, Number[] data2) {
		this.data1 = data1;
		this.data2 = data2;
	}

	@Override
	final Number[] process() {
		int size = Math.min(data1.length, data2.length);
		
		Number[] results = new Number[size];	
		
		for (int i=0; i<size; i++) {
			results[i] = NumberUtility.toNumber(processData(i));
		}
		
		return results;
	}
	
}
