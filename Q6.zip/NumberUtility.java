
public class NumberUtility {

	private NumberUtility() { }
	
	public static Number sum(Number[] numbers) {
		double dotProduct = 0.0;
		
		for (Number number : numbers) {
			dotProduct += number.doubleValue();
		}
		
		return toNumber(dotProduct);
	}	
	
	public static Number toNumber(double value) {
		if (value == (long)value)
			return (long)value;
		else
			return value;
	}
	
}
