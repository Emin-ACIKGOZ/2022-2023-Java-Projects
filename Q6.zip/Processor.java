
abstract public class Processor {
	
	abstract Number[] process();
	
	abstract double processData(int index);
			
}
