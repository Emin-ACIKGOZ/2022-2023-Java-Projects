

public class OperatorMismatchException extends RuntimeException { 
	OperatorMismatchException(String errorMessage) {
		super(errorMessage);
	}
        OperatorMismatchException() {
		super();
	}
}