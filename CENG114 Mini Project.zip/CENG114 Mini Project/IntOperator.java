

public class IntOperator extends Operator {

    private final int value;

    IntOperator(int value) {
        this.value = value;
    }

    @Override
    Operator add(Operator op) {

        IntOperator intOp = (IntOperator) op;

        int intVal = intOp.value;

        return new IntOperator(this.value + intVal);
    }

    @Override
    Operator multiply(Operator op) {
        IntOperator intOp = (IntOperator) op;

        int intVal = intOp.value;

        return new IntOperator(this.value * intVal);

    }

    @Override
    Operator subtract(Operator op) {
        IntOperator intOp = (IntOperator) op;
        int intVal = intOp.value;

        return new IntOperator(this.value - intVal);
    }

    @Override
    public String toString() {
        return this.value < 0 ? "(" + this.value + ")" : "" + this.value;

    }

    @Override
    public String getDetails() {
        return "";
    }

    @Override
    public int getDistance(Operator target) {

        try {
            IntOperator intOp = (IntOperator) this;
            IntOperator intTarget = (IntOperator) target;

            return Math.abs(intOp.value - intTarget.value);

        } catch (RuntimeException e) {
            return Integer.MAX_VALUE;
        }

    }

}
