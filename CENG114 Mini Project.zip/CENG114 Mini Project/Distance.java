

public interface Distance {
	int getDistance(Operator target);
}
