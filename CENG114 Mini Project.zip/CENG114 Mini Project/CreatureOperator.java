

public class CreatureOperator extends Operator {

    private final boolean canSwim;
    private final boolean canWalk;
    private final boolean canDig;
    private final boolean canFly;

    private final String name;

    private final int speed;
    private final int health;
    private final int strength;

    CreatureOperator(String name, int speed, int health, int strength, boolean canSwim, boolean canWalk, boolean canDig, boolean canFly) {
        this.name = name;

        this.speed = (speed < 0 ? 0 : speed);
        this.health = (health < 1 ? 1 : health);
        this.strength = (strength < 0 ? 0 : strength);

        this.canSwim = canSwim;
        this.canWalk = canWalk;
        this.canDig = canDig;
        this.canFly = canFly;
    }

    @Override
    Operator add(Operator op) {
        CreatureOperator animalOp = (CreatureOperator) op;

        int resultingSpeed = this.speed + animalOp.speed;
        int resultingHealth = this.health + animalOp.health;
        int resultingStrength = this.strength + animalOp.strength;

        boolean resultingCanSwim = animalOp.canSwim || this.canSwim;
        boolean resultingCanWalk = animalOp.canWalk || this.canWalk;
        boolean resultingCanDig = animalOp.canDig || this.canDig;
        boolean resultingCanFly = animalOp.canFly || this.canFly;

        String resultingName = this.name + animalOp.name;

        return new CreatureOperator(
                resultingName, resultingSpeed,
                resultingHealth, resultingStrength,
                resultingCanSwim, resultingCanWalk,
                resultingCanDig, resultingCanFly
        );
    }

    @Override
    Operator multiply(Operator op) {
        CreatureOperator animalOp = (CreatureOperator) op;

        int resultingSpeed = (animalOp.speed + this.speed) / 2;
        int resultingHealth = (animalOp.health + this.health) / 2;
        int resultingStrength = (animalOp.strength + this.strength) / 2;

        boolean resultingCanSwim = this.canSwim;
        boolean resultingCanWalk = this.canWalk;

        boolean resultingCanDig = animalOp.canDig;
        boolean resultingCanFly = animalOp.canFly;

        StringBuilder combinedName = new StringBuilder();
        combinedName.append(this.name, 0, this.name.length() / 2);
        combinedName.append(animalOp.name, animalOp.name.length() / 2, animalOp.name.length());

        return new CreatureOperator(
                combinedName.toString(), resultingSpeed,
                resultingHealth, resultingStrength,
                resultingCanSwim, resultingCanWalk,
                resultingCanDig, resultingCanFly
        );

    }

    @Override
    Operator subtract(Operator op) {
        CreatureOperator animalOp = (CreatureOperator) op;

        int resultingSpeed = this.speed - animalOp.speed;
        int resultingHealth = this.health - animalOp.health;
        int resultingStrength = this.strength - animalOp.strength;
        
        //This logical pattern behaves like substraction
        // true - true is false
        // true - false is true
        // false - false is false
        // false - true is false
        // it removes any common attributes
        
        boolean resultingCanSwim = (this.canSwim == true && animalOp.canSwim  == false);
        boolean resultingCanWalk = (this.canWalk == true && animalOp.canWalk  == false);
        boolean resultingCanDig = (this.canDig == true && animalOp.canDig  == false);
        boolean resultingCanFly = (this.canFly == true && animalOp.canFly  == false);

        StringBuilder resultingName = new StringBuilder(this.name);
        StringBuilder animalOpName = new StringBuilder(animalOp.name);

        for (int i = 0; i < resultingName.length(); i++) {
            char ch = resultingName.charAt(i);
            int index = animalOpName.indexOf(String.valueOf(ch));
            if (index != -1) {
                resultingName.deleteCharAt(i);
                animalOpName.deleteCharAt(index);
                i--;
            }
        }

        return new CreatureOperator(
                resultingName.toString(), resultingSpeed,
                resultingHealth, resultingStrength,
                resultingCanSwim, resultingCanWalk,
                resultingCanDig, resultingCanFly
        );
    }

    @Override
    public String toString() {
        return this.name;
    }

    @Override
    public String getDetails() {
        StringBuilder sb = new StringBuilder();
        sb.append("Name: ").append(this.name).append("\n");
        sb.append("Speed: ").append(this.speed).append("\n");
        sb.append("Health: ").append(this.health).append("\n");
        sb.append("Strength: ").append(this.strength).append("\n");
        sb.append("canSwim: ").append(this.canSwim).append("\n");
        sb.append("canWalk: ").append(this.canWalk).append("\n");
        sb.append("canDig: ").append(this.canDig).append("\n");
        sb.append("canFly: ").append(this.canFly);
        return sb.toString();
    }

    @Override
    public int getDistance(Operator target) {
        try {
            CreatureOperator animalOp = (CreatureOperator) this;
            CreatureOperator animalTarget = (CreatureOperator) target;

            int distance = 0;

            distance += Math.abs((animalTarget.health + animalTarget.speed + animalTarget.strength) - (animalOp.speed + animalOp.health + animalOp.strength));

            if (animalOp.canSwim ^ animalTarget.canSwim) {
                distance = (distance+1)*2;
            }
            if (animalOp.canFly ^ animalTarget.canFly) {
                distance = (distance+1)*2;
            }
            if (animalOp.canDig ^ animalTarget.canDig) {
                distance = (distance+1)*2;
            }
            if (animalOp.canWalk ^ animalTarget.canWalk) {
                distance = (distance+1)*2;
            }
            return distance;

        } catch (RuntimeException e) {
            return Integer.MAX_VALUE;
        }
    }

}
