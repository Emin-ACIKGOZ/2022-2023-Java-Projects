EMİN SALİH AÇIKGOZ 22050111032: Wrote OpSolver class and its methods, Revised methods, Contributed test cases, tested for exceptions and unwanted behavior, Revised CreatureOperator class

EMİRCAN KASAP 21050111060: Wrote Operator classes and their methods; Contributed test cases, Revised methods, added measures against exceptions and unwanted behavior

FATİH ÇAKIR 21050111007 and HAVVA NİSA ALTINBAŞ 21050111014: Wrote CreatureOperator class, Contributed test cases

The files named after classes are the documentation of each class respectively