

public class StrOperator extends Operator {

    private final String value;

    StrOperator(String value) {
        this.value = value;
    }

    @Override
    Operator add(Operator op) {
        StrOperator strOp = (StrOperator) op;

        StringBuilder sb = new StringBuilder(this.value);
        sb.append(strOp.value);

        return new StrOperator(sb.toString());
    }

    @Override
    Operator multiply(Operator op) {

        StrOperator strOp = (StrOperator) op;

        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < this.value.length(); i++) {
            sb.append(this.value.charAt(i));
            sb.append(strOp.value);
        }

        return new StrOperator(sb.toString());
    }

    @Override
    Operator subtract(Operator op) {
        StrOperator strOp = (StrOperator) op;

        StringBuilder sb = new StringBuilder();

        int lastOccurence = this.value.lastIndexOf(strOp.value);
        if (lastOccurence >= 0) {
            sb.append(this.value.substring(0, lastOccurence));
            sb.append(this.value.substring(lastOccurence + strOp.value.length(), this.value.length()));
            return new StrOperator(sb.toString());
        } else {
            return new StrOperator(this.value);
        }
    }

    @Override
    public String toString() {
        return this.value;
    }

    @Override
    public String getDetails() {
        return "";
    }

    @Override
    public int getDistance(Operator target) {
        try {
            StrOperator strOp = (StrOperator) this;
            StrOperator targetOp = (StrOperator) target;
            String opValue = strOp.value;

            return getStrDistance(opValue, targetOp.value);
        } catch (RuntimeException e) {
            return Integer.MAX_VALUE;
        }
    }

    public static int getStrDistance(String str1, String str2) {
        int n1 = str1.length();
        int n2 = str2.length();
        int n = Math.max(n1, n2);

        int distance = 0;
        for (int i = 0; i < n; i++) {
            char ch1 = (i < n1 ? str1.charAt(i) : ' ');
            char ch2 = (i < n2 ? str2.charAt(i) : ' ');

            distance += Math.abs(ch1 - ch2);
        }

        return distance;
    }

}
