

public abstract class Operator implements Distance{

	abstract Operator add(Operator op);
	abstract Operator multiply(Operator op);
	abstract Operator subtract(Operator op);
	public abstract String toString();
	abstract String getDetails();

}
