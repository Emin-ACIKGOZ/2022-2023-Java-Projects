

public class OperatorTest {

    static void testOp(Operator op1, Operator op2) {
        System.out.println("op1: " + op1);
        System.out.println(op1.getDetails());
        System.out.println("----");

        System.out.println("op2: " + op2);
        System.out.println(op2.getDetails());
        System.out.println("----");

        System.out.println("Addition:");
        System.out.println(op1.add(op2));
        System.out.println(op1.add(op2).getDetails());
        System.out.println("----");

        System.out.println("Multiplication:");
        System.out.println(op1.multiply(op2));
        System.out.println(op1.multiply(op2).getDetails());
        System.out.println("----");

        System.out.println("Subtraction:");
        System.out.println(op1.subtract(op2));
        System.out.println(op1.subtract(op2).getDetails());
        System.out.println("----");

        System.out.println("Subtraction (Reverse Order):");
        System.out.println(op2.subtract(op1));
        System.out.println(op2.subtract(op1).getDetails());

        System.out.println("----------");
        System.out.println();
    }

    public static void main(String[] args) {

        //Int Operator Test 
        System.out.println("Integer Operator Test");
        System.out.println();

        Operator op1 = new IntOperator(12);
        Operator op2 = new IntOperator(5);

        testOp(op1, op2);

        // Animal Operator Test
        System.out.println("Animal Operator Test");

        op1 = new CreatureOperator("Cat", 2, 2, 2, false, true, true, false);
        op2 = new CreatureOperator("Bat", 5, 4, 4, false, false, false, true);

        testOp(op1, op2);
        testOp(op2, op1);

        // Str Operator Test
        System.out.println("String Operator Test");
        op1 = new StrOperator("ABCD");
        op2 = new StrOperator("EFGH");

        testOp(op1, op2);
        Operator op3 = op1.add(op2);

        //EFGH
        System.out.println(op3.subtract(op1));

        Operator N = new StrOperator("N");
        Operator A = new StrOperator("A");
        Operator R = new StrOperator("R");

        Operator NARA = new StrOperator((N.add(R).multiply(A)).toString());

        //NARA
        System.out.println(NARA);

        Operator B = new StrOperator("B");

        //NARA
        System.out.println(NARA.subtract(B));

        //NAR
        System.out.println(NARA.subtract(A));

        System.out.println("----------");
        System.out.println();

        //Distance Test
        System.out.println("Distance Test");
        System.out.println();

        //7
        op1 = new IntOperator(-2);
        int i = op1.getDistance(new IntOperator(5));
        System.out.println(i);

        //55
        op1 = new IntOperator(10);
        op2 = new IntOperator(6);
        int j = op1.multiply(op2).getDistance(new IntOperator(5));
        System.out.println(j);

        //3
        Operator ABC = new StrOperator("ABC");
        int k = ABC.getDistance(new StrOperator("BCD"));
        System.out.println(k);

        //Integer.MAXVALUE
        int l = op1.getDistance(new StrOperator("ABC"));
        System.out.println(l);

        //128
        int m = NARA.getDistance(new StrOperator("B"));
        System.out.println(m);

        //0 
        int n = NARA.getDistance(new StrOperator("NARA"));
        System.out.println(n);

        //0
        Operator op6 = new StrOperator("");
        System.out.println(op6.getDistance(new StrOperator("")));

        Operator cat = new CreatureOperator("cat", 10, 7, 4, true, true, true, false);
        Operator bird = new CreatureOperator("bird", 10, 2, 1, false, true, true, true);
        Operator monkey = new CreatureOperator("monkey", 8, 5, 6, true, true, true, false);

        Operator fish = new CreatureOperator("fish", 6, 1, 1, true, false, true, false);

        // 38
        System.out.println(fish.getDistance(cat.add(bird).multiply(monkey)));

        // 0
        System.out.println(fish.getDistance(fish));

        System.out.println("----------");
        System.out.println();

        // Solver Test
        //TEST 1
        System.out.println("TEST 1");
        Operator[] input = {
            new StrOperator("K"),
            new StrOperator("LT"),
            new StrOperator("I"),};
        Operator target = new StrOperator("KILIT");
        //LITIK is the closest by how string distance is calculated

        long start = System.nanoTime();
        String answer = OpSolver.findSolution(input, target);
        long finish = System.nanoTime();

        System.out.println(answer);

        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        //TEST 2 
        System.out.println("TEST 2");
        Operator[] input2 = {
            new StrOperator("R"),
            new StrOperator("K"),
            new StrOperator("A"),
            new StrOperator("A"),
            new StrOperator("T"),
            new StrOperator("S"),};
        Operator KARATAS = new StrOperator("KARATAS");

        // KARATAS is our target
        start = System.nanoTime();
        answer = OpSolver.findSolution(input2, KARATAS);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        // TEST 3 
        System.out.println("TEST 3");
        Operator[] input3 = {
            new IntOperator(11),
            new IntOperator(7),
            new IntOperator(12),
            new IntOperator(6)
        };

        Operator target3 = new IntOperator(41);

        start = System.nanoTime();
        answer = OpSolver.findSolution(input3, target3);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        // TEST 4 
        System.out.println("TEST 4");
        Operator[] input4 = {
            new IntOperator(19),
            new IntOperator(22),
            new IntOperator(37),
            new IntOperator(13),
            new IntOperator(31),
            new IntOperator(32),};

        Operator target4 = new IntOperator(15526);

        start = System.nanoTime();
        answer = OpSolver.findSolution(input4, target4);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();
        // TEST 5 
        System.out.println("TEST 5");
        Operator[] input5 = {
            new IntOperator(11),
            new IntOperator(7),
            new IntOperator(12),
            new IntOperator(-6)
        };

        Operator target5 = new IntOperator(100);

        start = System.nanoTime();
        answer = OpSolver.findSolution(input5, target5);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        // TEST 6
        System.out.println("TEST 6");
        Operator[] input6 = {N, A, A, R,};

        Operator target6 = new StrOperator("NARAA");

        start = System.nanoTime();
        answer = OpSolver.findSolution(input6, target6);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        //TEST 7 
        System.out.println("TEST 7");
        Operator[] input7 = {N, A, A, R};

        Operator target7 = new IntOperator(123);

        start = System.nanoTime();
        try {
            answer = OpSolver.findSolution(input7, target7);
        } catch (OperatorMismatchException e) {
            System.out.println(e);
        }
        finish = System.nanoTime();

        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        //TEST 8 
        System.out.println("TEST 8");
        Operator[] input8 = {fish, monkey, cat};

        Operator orangutang = new CreatureOperator("orangutang", 14, 7, 5, true, true, true, false);

        start = System.nanoTime();
        try {
            answer = OpSolver.findSolution(input8, orangutang);
        } catch (OperatorMismatchException e) {
            System.out.println(e);
        }
        finish = System.nanoTime();
        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        // TEST 9 Handling null and types that are not of the target's type
        System.out.println("TEST 9");
        Operator[] input9 = {new StrOperator("BB"), null, null, new IntOperator(123), cat, fish};

        start = System.nanoTime();
        try {
            answer = OpSolver.findSolution(input9, fish);
        } catch (OperatorMismatchException e) {
            System.out.println(e);
        }
        finish = System.nanoTime();
        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

        // TEST 10 Handling Operator arrays that contain incorrect types
        System.out.println("TEST 10");
        Operator[] input10 = {
            R, A, R, N,
            new IntOperator(123),
            new IntOperator(12),
            new IntOperator(133)
        };

        // NARA is our target
        start = System.nanoTime();
        answer = OpSolver.findSolution(input10, NARA);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();

//TEST 11
        System.out.println("TEST 11");
        Operator[] input11 = {
            new CreatureOperator("lion", 7, 9, 8, true, true, true, false),
            new CreatureOperator("tiger", 8, 9, 10, true, true, true, false),
            new CreatureOperator("elephant", 1, 10, 10, true, true, true, false),
            new CreatureOperator("eagle", 10, 7, 7, false, true, true, true),};

        Operator target11 = new CreatureOperator("canary", 4, 1, 1, false, false, false, true);

        start = System.nanoTime();
        answer = OpSolver.findSolution(input11, target11);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        //TEST 12
        System.out.println("TEST 12");
        Operator[] input12 = {
            new CreatureOperator("lion", 7, 9, 8, true, true, true, false),
            new CreatureOperator("tiger", 8, 9, 10, true, true, true, false),
            new CreatureOperator("elephant", 1, 10, 10, true, true, true, false),
            new CreatureOperator("eagle", 10, 7, 7, false, true, true, true),};

        Operator target12 = new CreatureOperator("fly", 2, 1, 1, false, false, false, true);

        start = System.nanoTime();
        answer = OpSolver.findSolution(input12, target12);
        finish = System.nanoTime();

        System.out.println(answer);
        System.out.println("Execution time is " + ((finish - start) / 1e6) + " ms");

        System.out.println();
    }

}
