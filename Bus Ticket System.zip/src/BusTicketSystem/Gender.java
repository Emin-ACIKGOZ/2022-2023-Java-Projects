package BusTicketSystem;

public enum Gender {
	    Male, Female;
}
