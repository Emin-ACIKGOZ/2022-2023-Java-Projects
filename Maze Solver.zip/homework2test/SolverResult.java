//Name: Emin Salih Açıkgöz 
//Student NO: 22050111032
package homework2test;

public class SolverResult {

    //I believe the code here is self explainatory, therefore I will not comment upon most of the code here
    //The integers keep track of deaths,failures and successes that occur in RandomMazeSolver
    //They are used to calculate their respective percentages
    //I used the pre-existing getters in these methods for the sake of not having them unused
    private int deadCount = 0;
    private int failureCount = 0;
    private int successCount = 0;

    int getTotal() {
        return getDeadCount() + getFailureCount() + getSuccessCount();
    }

    void incrementDead() {
        deadCount++;
    }

    int getDeadCount() {
        return deadCount;
    }

    double getDeadPercentage() {
        int total = getTotal();

        return total > 0 ? (100.0 * getDeadCount()) / total : 0.0;
    }

    void incrementFailure() {
        failureCount++;
    }

    int getFailureCount() {
        return failureCount;
    }

    double getFailurePercentage() {
        int total = getTotal();

        return total > 0 ? (100.0 * getFailureCount()) / total : 0.0;
    }

    void incrementSuccess() {
        successCount++;
    }

    int getSuccessCount() {
        return successCount;
    }

    double getSuccessPercentage() {
        int total = getTotal();

        return total > 0 ? (100.0 * getSuccessCount()) / total : 0.0;
    }

    @Override
    public String toString() {
        return "Dead percentage: " + getDeadPercentage() + "%\n"
                + "Failure percentage: " + getFailurePercentage() + "%\n"
                + "Success percentage: " + getSuccessPercentage() + "%";
    }
}
