//Name: Emin Salih Açıkgöz 
//Student NO: 22050111032
package homework2test;

public class Location {

    //Two values that represent a 2D point on a plane
    private int x;
    private int y;

    Location(int x, int y) {
        this.x = x;
        this.y = y;
        //Set a location object with the coordinates (x,y)
    }

    Location(Location location) {
        this.x = location.getX();
        this.y = location.getY();
        //Set a location object using another location object
    }

    boolean equals(int x, int y) {
        return this.x == x && this.y == y;
        //Compares coordinates inputted as integers to the coordinates of objects
        //Returns true if both coordinates match
    }

    //These getters and setters make the code safer
    int getX() {
        return this.x;
    }

    void setX(int x) {
        this.x = x;
    }

    int getY() {
        return this.y;
    }

    void setY(int y) {
        this.y = y;
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) {
            //Returns true as both are Object instances and therefore don't hold coordinates
            return true;
        } else {
            if (obj instanceof Location) {
                //Type-casts the Object to Location and then compares its coordinates with the object's
                Location objLocation = (Location) obj;
                return this.x == objLocation.x && this.y == objLocation.y;
            } else {
                return false;
            }
        }
    }

    @Override
    public String toString() {
        return "P(" + x + ", " + y + ")";
    }
}
