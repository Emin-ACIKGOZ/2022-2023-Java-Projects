//Name: Emin Salih Açıkgöz 
//Student NO: 22050111032
package homework2test;

public class RandomMazeSolver {

    private RandomMazeSolver() {
        //This appears to not be used so I made it private
    }

    static SolverResult solve(World world, int experimentCount) {
        SolverResult solverResult = new SolverResult();

        //A multiplier that affects how many turns the robot will get
        int trialFactor = 100;
        //Maximum amount of turns the robot can use
        int maximumTrialCount = trialFactor * world.getArea();

        for (int i = 0; i < experimentCount; i++) {
            if (i % 256 == 0) {
                //Every 256 times an experiment has occured, print one dot
                System.out.print(".");
            }
            //Run the experiment
            executeExperiment(world, maximumTrialCount);

            //Depending on the outcome increase the appropiate variable
            if (world.isRobotDead()) {
                solverResult.incrementDead();
            } else {
                if (world.isRobotAtEnd()) {
                    solverResult.incrementSuccess();
                } else {
                    solverResult.incrementFailure();
                }
            }
        }

        System.out.println("\n");

        return solverResult;
    }

    static void executeExperiment(World world, int maximumTrialCount) {
        //Refresh the world for another experiment
        world.restartTheWorld();
        //While there are turns remaining and the robot is not dead or at the end
        //Move the robot randomly and reduce the amount of remaining turns by one
        while (maximumTrialCount > 0 && !(world.isRobotDead() || world.isRobotAtEnd())) {
            maximumTrialCount--;
            world.moveRobotRandomly();
        }

    }

}
