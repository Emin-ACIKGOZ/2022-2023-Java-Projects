//Name: Emin Salih Açıkgöz 
//Student NO: 22050111032
package homework2test;

import java.util.Random;

public class World {

    private static Random rand = new Random();
    private final int initialLifeCount = 100;
    private int robotLifeCount;
    private Location robot = null;
    private final Location start;
    private final Location end;
    private double holeProbability;
    private double wallProbability;

    enum CellType {
        Wall,
        Corridor;

        @Override
        public String toString() {
            return this == Wall ? "#" : ".";
            //Returns a cell as a # or a . for walls and corridors respectively
        }

        static CellType random(double wallProbability) {
            return (rand.nextDouble() < wallProbability ? Wall : Corridor);
            //Random numbers simulate probability and allow us to randomly make cells a wall or corridor
        }
    }

    final CellType[][] cells;
    //A 2D array that holds all the cells within it

    World(int width, int height, double holeProbability, double wallProbability, Location start, Location end) {
        this.holeProbability = holeProbability;
        this.wallProbability = wallProbability;
        this.start = start;
        this.end = end;

        cells = new CellType[height][width];
        //Creates the world
        restartTheWorld();
    }

    void restartTheWorld() {
        //Creates a new world and resets the robot
        createRandomMaze(holeProbability, wallProbability);
        rebootTheRobot();
    }

    void createRandomMaze(double holeProbability, double wallProbability) {
        //Iterates through the 2D array and assigns each cell a wall or corridor
        for (int y = 0; y < cells.length; y++) {
            CellType[] row = cells[y];

            for (int x = 0; x < row.length; x++) {
                if (start.equals(x, y) || end.equals(x, y)) {
                    //Always sets the start and end points as a corridor
                    row[x] = CellType.Corridor;
                } else {
                    if (rand.nextDouble() > holeProbability) {
                        //If the random value is greater than holeProbability the current cell will be a wall or corridor
                        //If it is equal or lesser the current cell will be a hole
                        row[x] = CellType.random(wallProbability);
                    } else {
                        row[x] = null;
                    }
                }
            }
        }
    }

    int getArea() {
        //Returns the area of our world
        return cells.length * cells[0].length;
    }

    void rebootTheRobot() {
        //Resets the robot's life count and sets its location to the starting point
        robotLifeCount = initialLifeCount;
        this.robot = new Location(start);
    }

    boolean isRobotDead() {
        //Returns true if the robot has no more lives left
        return (robotLifeCount <= 0);
    }

    boolean isRobotAtStart() {
        //Checks coordinates of start and returns true if it matches the robot's coordinates
        return !isRobotDead() && robot.equals(start);
    }

    boolean isRobotAtEnd() {
        //Returns true if robot is not dead at has the same coordinates as end
        return !isRobotDead() && robot.equals(end);
    }

    CellType robotAt() {
        //Returns null if the robot is null, else it returns the cell the robot is on
        return (robot == null) ? null : cells[robot.getY()][robot.getX()];
    }

    void moveRobotRandomly() {
        int deltaX, deltaY;
        //delta X and Y represent the change in position of the robot

        //The deltas will be between -1 and +2 and their absolute values cannot add up to one
        do {
            deltaX = rand.nextInt(-1, 2);
            deltaY = rand.nextInt(-1, 2);
        } while (Math.abs(deltaX) + Math.abs(deltaY) != 1);

        //These are the new coordinates of the robot
        int newX = robot.getX() + deltaX;
        int newY = robot.getY() + deltaY;

        //canMove will be true if the target position is a valid position and not a wall cell
        boolean canMove = (newY >= 0 && newY < cells.length
                && newX >= 0 && newX < cells[newY].length
                && cells[newY][newX] != CellType.Wall);

        if (canMove) {
            robot.setX(newX);
            robot.setY(newY);

            //The robot will die if the space it moved onto is a hole (null)
            if (this.robotAt() == null) {
                robotLifeCount--;
            }
        }
    }

    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();

        for (int y = 0; y < cells.length; y++) {
            CellType[] row = cells[y];

            for (int x = 0; x < row.length; x++) {
                if (robot != null && robot.equals(x, y)) {
                    //If the current position is the same as the robot's position represent the cell as a star
                    sb.append("*");
                } else {
                    if (row[x] == null) {
                        //If the cell is empty represent it as an x
                        sb.append("x");
                    } else {
                        if (start.equals(x, y)) {
                            //if the current coordinates match start's represent it as S
                            sb.append("S");
                        } else if (end.equals(x, y)) {
                            //if the current coordinates match end's represent it as E
                            sb.append("E");
                        } else {
                            //Represent the current cell as a corridor or wall
                            sb.append(row[x]);
                        }
                    }
                }
            }
            //Make the stringbuilder go to the next line
            sb.append("\n");
        }

        return sb.toString();
    }

}
