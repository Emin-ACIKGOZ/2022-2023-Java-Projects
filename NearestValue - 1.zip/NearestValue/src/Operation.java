
public abstract class Operation{
	
	//final double value;
	final Operation leftChild;
	final Operation rightChild;
	
	
	Operation(Operation leftChild,Operation rightChild){
		//this.value = Double.NaN;
		
		if(leftChild != null && rightChild != null) {
			this.leftChild = leftChild;
			this.rightChild = rightChild;
		}
		else {
			this.leftChild = null;
			this.rightChild = null;
		}
	
	}
	

public abstract Object getValue();
        
	@Override
	public abstract String toString();
        
        public boolean isLeaf(){
            return this.leftChild == null && this.rightChild == null;
        }
}
