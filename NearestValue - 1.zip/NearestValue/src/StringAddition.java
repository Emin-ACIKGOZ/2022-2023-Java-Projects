/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author emins
 */
public class StringAddition extends StringOperation {
    
    StringAddition(StringOperation leftChild, StringOperation rightChild) {
        super(leftChild, rightChild);
    }
    
    @Override
    public Object getValue() {
        if (this.isLeaf()) {
            return this.value;
        } else {
            return (String) this.leftChild.getValue() + (String) this.rightChild.getValue();
        }
    }
    
    @Override
    public String toString(){
        return "(" + this.leftChild.toString() + " + " + this.rightChild.toString() + ")" ;
    }
    
    
}
