/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author emins
 */
public class NumberMultiplication extends NumberOperation {

    NumberMultiplication(NumberOperation leftChild, NumberOperation rightChild) {
        super(leftChild, rightChild);
    }
    
    @Override
    public Object getValue() {
        if (this.isLeaf()) {
            return this.value;
        } else {
            return (Double) this.leftChild.getValue() * (Double) this.rightChild.getValue();
        }
    }

    @Override
    public String toString() {
        if (this.isLeaf()) {
            return this.value + "";
        }else{
            return "(" + leftChild.toString() + " * " + rightChild.toString() + ")";
        }
        
    }
}
