/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


/**
 *
 * @author emins
 */
public class StringMultiplication extends StringOperation {
    
    StringMultiplication(StringOperation leftChild, StringOperation rightChild) {
        super(leftChild, rightChild);
    }
    
    @Override
    public Object getValue() {
        if (this.isLeaf()) {
            return this.value;
        } else {
            StringBuilder result = new StringBuilder();
            String L = (String)leftChild.getValue();
            String R = (String)rightChild.getValue();          
            int length = L.length();
            
            for (int i = 0; i < length; i++) {
                result.append(L.charAt(i));
                result.append(R);
            }
            return result.toString();
            
        }
    }

    @Override
    public String toString(){
        return "(" + this.leftChild.toString() + " * " + this.rightChild.toString() + ")" ;
    }
}
