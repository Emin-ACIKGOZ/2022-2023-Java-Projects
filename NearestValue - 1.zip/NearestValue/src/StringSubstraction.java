/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */



/**
 *
 * @author emins
 */
public class StringSubstraction extends StringOperation {
    
    StringSubstraction(StringOperation leftChild, StringOperation rightChild) {
        super(leftChild, rightChild);
    }
    
    @Override
    public Object getValue() {
        if (this.isLeaf()) {
            return this.value;
        } else {
            
            String L = (String)leftChild.getValue();
            String R = (String)rightChild.getValue();  
            
            int lastOccurence = L.lastIndexOf(R);
            if(lastOccurence >= 0){
                return L.substring(0, lastOccurence) + L.substring(lastOccurence+R.length(), L.length());
            }else{
                return L;
            }
              
        }
    }

    @Override
    public String toString(){
        return "(" + this.leftChild.toString() + " - " + this.rightChild.toString() + ")" ;
    }
}
