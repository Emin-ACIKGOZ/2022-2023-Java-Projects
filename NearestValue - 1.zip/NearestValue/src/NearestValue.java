

/**
 *
 * @author emins
 */
public class NearestValue {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        NumberNode test1 = new NumberNode(12);
        NumberNode test2 = new NumberNode(5);
        NumberAddition test3 = new NumberAddition(test1,test2);
        NumberAddition test4 = new NumberAddition(test3 , test3);
        System.out.println( test4.toString() + " = "+ test4.getValue());
        
        StringNode A = new StringNode("N");
        StringNode B = new StringNode("R");
        StringNode C = new StringNode("A");
        StringAddition D = new StringAddition(A, B);
        StringMultiplication E = new StringMultiplication(D , C);
        System.out.println(A);
        System.out.println(B);
        System.out.println(C);
        System.out.println(D);
        System.out.println(D.getValue());
        System.out.println("------");
        System.out.println(E);
        System.out.println(E.getValue());
        StringNode F = new StringNode("AeR");
        StringSubstraction G = new StringSubstraction(E, F);
        System.out.println("*****");
        System.out.println(G);
        System.out.println(G.getValue());
        
    }
    
}
